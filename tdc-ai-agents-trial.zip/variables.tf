variable "tenancy_ocid" {
  description = "OCID da tenancy trial. O Resource Manager preenche esta variavel sozinho quando o nome bate exatamente com 'tenancy_ocid'."
  type        = string
}

variable "deployment_region" {
  description = "Regiao OCI onde Compute e OCI Generative AI do lab vao rodar. O padrao e Ashburn (us-ashburn-1)."
  type        = string
  default     = "us-ashburn-1"
}

variable "home_region" {
  description = "Home region da tenancy, usada exclusivamente para recursos de IAM. Para esta tenancy, use Ashburn (us-ashburn-1)."
  type        = string
  default     = "us-ashburn-1"
}

variable "compartment_name" {
  description = "Nome do compartment criado do zero para o lab."
  type        = string
  default     = "tdc-ai-agents-lab-tdcsp2026"
}

variable "compartment_description" {
  type    = string
  default = "Recursos do laboratorio TDC AI Agents OCI (Terraform)"
}

variable "dynamic_group_name" {
  description = "Nome do dynamic group que agrupa a VM do lab. A policy do lab e concedida a este dynamic group."
  type        = string
  default     = "tdc-ai-agents-vm-tdcsp2026"
}

variable "policy_name" {
  type    = string
  default = "tdc-ai-agents-lab-policy-tdcsp2026"
}

variable "vcn_cidr" {
  type    = string
  default = "10.0.0.0/16"
}

variable "public_subnet_cidr" {
  description = "CIDR da subnet publica onde a VM do agente roda."
  type        = string
  default     = "10.0.0.0/24"
}

variable "instance_ocpus" {
  description = "OCPUs da VM. Usado tanto pra checar capacidade disponivel quanto pra criar a VM de fato."
  type        = number
  default     = 1
}

variable "instance_memory_in_gbs" {
  description = "Memoria da VM em GB para os shapes Flex. O fallback Always Free VM.Standard.E2.1.Micro usa sua configuracao fixa."
  type        = number
  default     = 6
}

variable "app_port" {
  description = "Porta onde o Assistente TDC Sao Paulo fica escutando. E a mesma porta liberada na security list e usada no chat_url."
  type        = number
  default     = 8080
}

variable "ssh_public_key" {
  description = "Sua chave publica SSH, para acessar a VM e ver logs (journalctl -u tdc-agent). Pode deixar vazio se nao precisar de SSH."
  type        = string
  default     = ""
}

variable "model_id" {
  description = "Modelo usado no OCI Generative AI. O catalogo de modelos disponivel varia por regiao - confira em Analytics & AI > Generative AI > Playground quais aparecem para a sua. O app suporta tanto modelos Cohere (cohere.*) quanto os demais (meta.*, xai.*, google.*, openai.*), detectando o formato pelo prefixo do nome."
  type        = string
  default     = "google.gemini-2.5-flash"
}

variable "agent_instruction" {
  description = "Instrucoes do agente (system prompt). Substitui o texto padrao."
  type        = string
  default     = <<-EOT
    Voce e o Assistente TDC Sao Paulo, um agente simpatico e prestativo para orientar participantes sobre o TDC Sao Paulo 2026.
    Responda em portugues brasileiro, de forma clara, objetiva e educada.
    Cumprimentos e conversa informal (oi, ola, bom dia, tudo bem, obrigado) devem receber uma resposta natural e simpatica, contando brevemente com o que voce pode ajudar. Nunca diga que precisa chamar uma funcao ou tool para responder isso, e nunca recuse uma mensagem so porque ela nao pede uma acao especifica.
    Use os documentos de contexto para perguntas gerais sobre o evento, jornadas, formato, FAQ, regras e links oficiais.
    Use obrigatoriamente a tool consulta_programacao_tdc quando a pergunta pedir agenda, programacao, trilhas por dia, horarios, palestras, sessoes, speakers, nomes de pessoas ou busca por termo - inclusive quando a pergunta for uma continuacao curta como "que dia" ou "que horas", usando o historico da conversa para entender a quem ou a qual sessao ela se refere.
    Nao invente horarios, speakers, valores ou regras que nao estejam no contexto ou na resposta da tool.
  EOT
}

variable "custom_tool_api_url" {
  description = "URL opcional de uma API externa de programacao. Deixe vazia para usar a agenda oficial do TDC Sao Paulo 2026 pelo endpoint /sessions/search da propria VM."
  type        = string
  default     = ""
}

variable "telegram_bot_token" {
  description = "Token do bot do Telegram (gerado pelo @BotFather). Opcional - deixe vazio para nao ligar o Telegram; a interface web funciona de qualquer jeito."
  type        = string
  default     = ""
  sensitive   = true
}
